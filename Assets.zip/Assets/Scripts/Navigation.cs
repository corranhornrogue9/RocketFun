using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Navigation : MonoBehaviour
{
    // Start is called before the first frame update
    SimpleSeeker seeker;
    RocketMotor motor;
    DateTime startTime;
    public float accuracy = 0.1f;
    public float manouvreFidelty = 900f;
    Rigidbody rigidbody;
    public bool DirectMode = false;

    public float mavovrabilty = 5;
    float boostFuel;


    public float frust = 20f;
    public float NEZ = 250;
    public float wayPointSize = 250;

    public List<NavigationPoint> navpoints;

    void Start()
    {
        seeker = GetComponent<SimpleSeeker>();
        motor = GetComponent<RocketMotor>();
        startTime =  DateTime.Now;
        rigidbody = GetComponent<Rigidbody>();
        //Boost(3f);
    }

    public void Boost(float time)
    {
        boostFuel = time;
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    private void FixedUpdate()
    {
        if (DirectMode)
        {
            //PointDirectMode();
        }
        else
        {
            MaxThrustAdjust();
        }

       
    }

    /// <summary>
    /// <para>Assume speed is constant no need to calculate relative speed of laser to get interception pos!</para>
    /// <para>Calculates interception point between two moving objects where chaser speed is known but chaser vector is not known(Angle to fire at * speed"*Sort of*")</para>
    /// <para>Can use System.Math and doubles to make this formula NASA like precision.</para>
    /// </summary>
    /// <param name="PC">interceptor position</param>
    /// <param name="SC">Speed of laser</param>
    /// <param name="PR">Target initial position</param>
    /// <param name="VR">Target velocity vector</param>
    /// <returns>Interception Point as World Position</returns>
    public Vector3 CalculateInterceptionPoint3D(Vector3 PC, float SC, Vector3 PR, Vector3 VR)
    {
        //! Distance between turret and target
        Vector3 D = PC - PR;

        //! Scale of distance vector
        float d = D.magnitude;

        //! Speed of target scale of VR
        float SR = VR.magnitude;

        //% Quadratic EQUATION members = (ax)^2 + bx + c = 0

        float a = Mathf.Pow(SC, 2) - Mathf.Pow(SR, 2);

        float b = 2 * Vector3.Dot(D, VR);

        float c = -Vector3.Dot(D, D);

        if ((Mathf.Pow(b, 2) - (4 * (a * c))) < 0) //% The QUADRATIC FORMULA will not return a real number because sqrt(-value) is not a real number thus no interception
        {
            return Vector2.zero;//TODO: HERE, PREVENT TURRET FROM FIRING LASERS INSTEAD OF MAKING LASERS FIRE AT ZERO!
        }
        //% Quadratic FORMULA = x = (  -b+sqrt( ((b)^2) * 4*a*c )  ) / 2a
        float t = (-(b) + Mathf.Sqrt(Mathf.Pow(b, 2) - (4 * (a * c)))) / (2 * a);//% x = time to reach interception point which is = t

        //% Calculate point of interception as vector from calculating distance between target and interception by t * VelocityVector
        return ((t * VR) + PR);
    }

    private float ETA(Vector3 vector)
    {
        var addedSpeed = (frust * boostFuel);
       // Debug.Log("Speed+ " + addedSpeed);
        var boostSpeed = (Vector3.Project(rigidbody.velocity, vector).magnitude + (addedSpeed / 2));
        var topSpeed = Vector3.Project(rigidbody.velocity, vector).magnitude + addedSpeed;
       // Debug.Log("CurrentSpeed = " + rigidbody.velocity.magnitude);
      //  Debug.Log("CurrentVMG = " + Vector3.Project(rigidbody.velocity,vector).magnitude);
      //  Debug.Log("Distance = " + vector.magnitude);

        var distance = vector.magnitude;
        if(topSpeed < 0)
        {
            return float.MaxValue;
        }
        if(boostSpeed < 0)
        {
            distance += (float)(boostSpeed * -1 )* boostFuel;
          //  Debug.Log("Distance AfterBoost negative" + distance);
        }
        else
        {
            distance -= (float)(boostSpeed) * (float)boostFuel;
          //  Debug.Log("Distance AfterBoost" + distance);
        }

        return (distance / topSpeed) + boostFuel;

    }
    
    private float TopSpeed()
    {
        var addedSpeed = (frust * boostFuel);
        var topSpeed = rigidbody.velocity.magnitude + addedSpeed;
        return topSpeed;
    }

    private float PredictedSpeed(Vector3 intendedDirection)
    {
        var addedSpeed = (frust * boostFuel);
        var topSpeed = Vector3.Project(rigidbody.velocity, intendedDirection).magnitude + addedSpeed;
        return topSpeed;
    }

    private void MaxThrustAdjust()
    {
        var navPoint = navpoints.First();

        var targetPos = navPoint.gameObject.transform;


        if (navPoint.NavType == NavigationPoint.Type.Waypoint)
        {
            Debug.Log("Waypoint distance = " + (targetPos.position - transform.position).magnitude);
            if (wayPointSize > (targetPos.position - transform.position).magnitude)
            {

                navpoints.Remove(navPoint);
                navPoint = navpoints.First();
            }
        }

        boostFuel += navPoint.GetBoost();


        var currentDelte = rigidbody.velocity;
        var targetDelta = targetPos.position - transform.position;
        Rigidbody targetPhys;
        if (targetPos.gameObject.TryGetComponent<Rigidbody>(out targetPhys))
        {
            //Debug.Log("Current Speed = " + rigidbody.velocity.magnitude + " | EstimateSpeed = " + PredictedSpeed(targetPos.position - transform.position));

            var interceptPoint = CalculateInterceptionPoint3D(transform.position, PredictedSpeed(targetPos.position - transform.position), targetPos.position, targetPos.gameObject.GetComponent<Rigidbody>().velocity);
            targetDelta = interceptPoint - transform.position;

        }
       


        if(navPoint.NavType == NavigationPoint.Type.Endpoint)
        {
            var stopDistance = (0.5 * rigidbody.velocity.magnitude) * (rigidbody.velocity.magnitude / frust);
            boostFuel = 1;
            // add the time to turn around
            stopDistance += seeker.TimeToTargetRoate(-this.transform.up) * rigidbody.velocity.magnitude;
            stopDistance *= navPoint.safteyMargin;

            if (stopDistance > (navPoint.gameObject.transform.position - transform.position).magnitude)
            {
                targetDelta = -targetDelta; 
            }
        }

        var accruacyRangeAdjuster = Math.Min(Math.Max(targetDelta.magnitude / 500, 1), 5);

        if (Vector3.Angle(targetDelta, currentDelte) > accuracy * accruacyRangeAdjuster)
        {

            var correction = (targetDelta.normalized) - (currentDelte.normalized);

            seeker.SetTargetRotation(correction);

            if(Vector3.Angle(correction, transform.up) < manouvreFidelty)
            {
                //Debug.Log(Vector3.Angle(correction, transform.up) + "(" + Vector3.Angle(targetDelta, currentDelte) + " > " + accuracy * accruacyRangeAdjuster + ")" + " < " + manouvreFidelty);
                motor.m_Thrust = frust;
              //  Debug.Log("Manoviuering");
            }
            else
            {
                //Debug.Log(Vector3.Angle(correction, transform.up)+ "(" + Vector3.Angle(targetDelta, currentDelte) + " > " + accuracy * accruacyRangeAdjuster + ")" + " > " + manouvreFidelty);
                motor.m_Thrust = 0;
             //   Debug.Log("Not Manoviuering");
            }
        }
        else
        {
            seeker.SetTargetRotation(targetDelta);
            if(boostFuel > 0)
            {
                boostFuel -= Time.fixedDeltaTime;

                if(boostFuel < 0)
                {
                    boostFuel = 0;
               //     Debug.Log("end boost " + boostFuel + " at: " + DateTime.Now.TimeOfDay);
                }

                //Debug.Log("Boosting");

                motor.m_Thrust = frust;
            }
            else
            {
                motor.m_Thrust = 0f;
            }
        }

        if(NEZ > (targetPos.position - transform.position).magnitude)
        {
            motor.m_Thrust = frust;
        }
     
    }
    /*
    private void PointDirectMode()
    {
        Vector3 targetDelta = targetPos.position - transform.position;
        seeker.SetTargetRotation(targetDelta);

        if (OnRotTarget())
        {
            motor.m_Thrust = frust;

        }
        else
        {
            motor.m_Thrust = 0f;

        }
    }

    private bool OnRotTarget()
    {
        var retVal = false;
        Vector3 direction = (targetPos.position - transform.position).normalized;
        if(Vector3.Angle(direction, transform.up) < accuracy)
        {
            retVal = true;
        }
        

        return retVal;
    }
    */
}
