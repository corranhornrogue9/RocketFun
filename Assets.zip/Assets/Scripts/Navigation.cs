using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Navigation : MonoBehaviour
{
    // Start is called before the first frame update
    SimpleSeeker seeker;
    RocketMotor motor;
    public Transform targetPos;
    DateTime startTime;
    public float accuracy = 0.1f;
    Rigidbody rigidbody;
    public bool DirectMode = false;

    public float mavovrabilty = 5;
    TimeSpan boostTime;
    DateTime? boostStart;

    void Start()
    {
        seeker = GetComponent<SimpleSeeker>();
        motor = GetComponent<RocketMotor>();
        Vector3 targetDelta = targetPos.position - transform.position;
        seeker.SetTargetRotation(targetDelta);
        startTime =  DateTime.Now;
        rigidbody = GetComponent<Rigidbody>();
        Boost(TimeSpan.FromSeconds(3));
    }

    public void Boost(TimeSpan time)
    {
        boostTime = time;
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    private void FixedUpdate()
    {
        if (DirectMode)
        {
            PointDirectMode();
        }
        else
        {
            MaxThrustAdjust();
        }

       
    }
    
    private void MaxThrustAdjust()
    {
        var targetDelta = targetPos.position - transform.position;
        var currentDelte = rigidbody.velocity;

        var accruacyRangeAdjuster = Math.Min(Math.Max(targetDelta.magnitude / 500, 1), 5);
        Debug.Log(accruacyRangeAdjuster);
        if (Vector3.Angle(targetDelta, currentDelte) > accuracy * accruacyRangeAdjuster)
        {

            var correction = (targetDelta.normalized) - (currentDelte.normalized);

            seeker.SetTargetRotation(correction);

            if(Vector3.Angle(correction, transform.up) < accuracy)
            {
                motor.m_Thrust = 20f;
            }
            else
            {
                motor.m_Thrust = 20f;
            }
            boostStart = null;

        }
        else
        {
            seeker.SetTargetRotation(targetDelta);
            if(boostTime > TimeSpan.Zero)
            {
                if(!boostStart.HasValue)
                {
                    boostStart = DateTime.Now;
                }
                else
                {
                    try
                    {
                        boostTime = boostTime.Subtract(DateTime.Now - boostStart.Value);
                        
                    }
                    catch(Exception e)
                    {
                        boostTime = TimeSpan.Zero;
                        Debug.Log("Out of boost" + e.Message);
                    }
                }
                motor.m_Thrust = 20f;
                Debug.Log("boostboost" + boostTime);
            }
            else
            {
                boostStart = null;
                motor.m_Thrust = 0f;
            }
        }

       
     
    }

    private void PointDirectMode()
    {
        Vector3 targetDelta = targetPos.position - transform.position;
        seeker.SetTargetRotation(targetDelta);

        if (OnRotTarget())
        {
            motor.m_Thrust = 20f;

        }
        else
        {
            motor.m_Thrust = 0f;

        }
    }

    private bool OnRotTarget()
    {
        var retVal = false;
        Vector3 direction = (targetPos.position - transform.position).normalized;
        if(Vector3.Angle(direction, transform.up) < accuracy)
        {
            retVal = true;
        }
        

        return retVal;
    }
}
